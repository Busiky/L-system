import sys
from math import cos, sin, pi

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPen, QPainter
from PyQt5.QtWidgets import QApplication, QWidget, QFileDialog
from ui_lsystem_2 import Ui_Form


class MyWidget(QWidget, Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.filename = QFileDialog.getOpenFileName(self, 'Load file', '')[0]
        with open(self.filename, 'r', encoding='utf-8') as file:
            self.name = file.readline().strip()
            self.turn = 360 // int(file.readline().strip())
            self.axioma = file.readline().strip()
            self.theorema = {}
            for el in file:
                key, value = el.split()
                self.theorema[key] = value.strip()

        self.setWindowTitle(self.name)
        self.angle = 0
        self.rules = self.axioma
        self.step = 5
        self.x, self.y = 100, 400

        self.flag = False
        self.horizontalSlider.valueChanged.connect(self.draw)

    def iteration(self):
        temp = ''
        for i in range(self.iter):
            for symb in self.rules:
                if symb in self.theorema:
                    temp += self.theorema[symb]
                else:
                    temp += symb

            self.rules = temp
            temp = ''
        self.update()

    def draw(self, value):
        self.iter = value
        self.flag = True
        self.iteration()

    def paintEvent(self, event):
        if self.flag:
            qp = QPainter()
            qp.begin(self)
            self.draw_frac(qp)
            qp.end()

    def draw_frac(self, qp):
        pen = QPen(Qt.blue, 1)
        qp.setPen(pen)
        for rule in self.rules:
            if rule == 'F':
                qp.drawLine(
                    self.x, self.y,
                    self.x + self.step * cos(self.angle * pi / 180),
                    self.y + self.step * sin(self.angle * pi / 180)
                )
                self.x = self.x + self.step * cos(self.angle * pi / 180)
                self.y = self.y + self.step * sin(self.angle * pi / 180)
            elif rule == '+':
                self.angle += self.turn
            elif rule == '-':
                self.angle -= self.turn


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
