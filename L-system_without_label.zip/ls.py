import sys
from math import cos, sin, pi

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPen, QPainter
from PyQt5.QtWidgets import QApplication, QWidget
from ui_lsystem_1 import Ui_Form


class MyWidget(QWidget, Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        with open('dragon.ls', 'r', encoding='utf-8') as file:
            data = file.readlines()
        self.name = data[0]
        self.turn = 360 // int(data[1].rstrip())
        self.axioma = data[2]
        self.theorema = {}
        for el in data[3:]:
            key, value = el.rstrip().split()
            self.theorema[key] = value
        self.setWindowTitle(self.name)
        self.angle = 0
        self.rules = self.axioma
        print(self.name, self.turn, self.theorema, self.axioma)
        self.pushButton.clicked.connect(self.draw)

    def iteration(self):
        temp = ''
        for i in range(self.iter):
            for symb in self.rules:
                if symb in self.theorema:
                    temp += self.theorema[symb]
                else:
                    temp += symb

            self.rules = temp
            temp = ''
        qp = QPainter()

        for rule in self.rules:
            if rule == 'F':
                qp.begin(self)
                pen = QPen(Qt.blue, 1)
                qp.setPen(pen)
                qp.drawLine(
                    self.x, self.y,
                    self.x + self.step * cos(self.angle * pi / 180),
                    self.y + self.step * sin(self.angle * pi / 180)
                )

                qp.end()
                self.x += self.step * cos(self.angle * pi / 180)
                self.y += self.step * sin(self.angle * pi / 180)
            elif rule == '+':
                self.angle += self.turn
            elif rule == '-':
                self.angle -= self.turn
            print(self.x, self.y)

    def draw(self):
        print(self.rules)
        self.step = int(self.lineEdit.text())
        self.iter = int(self.lineEdit_2.text())
        self.x, self.y = map(int, self.lineEdit_3.text().split())

        self.iteration()

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)
        pen = QPen(Qt.blue, 1)
        qp.setPen(pen)
        for rule in self.rules:
            if rule == 'F':
                qp.drawLine(
                    self.x, self.y,
                    self.x + self.step * cos(self.angle * pi / 180),
                    self.y + self.step * sin(self.angle * pi / 180)
                )
                self.x += self.step * cos(self.angle * pi / 180)
                self.y += self.step * sin(self.angle * pi / 180)
            elif rule == '+':
                self.angle += self.turn
            elif rule == '-':
                self.angle -= self.turn
            print(self.x, self.y)
        qp.end()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
